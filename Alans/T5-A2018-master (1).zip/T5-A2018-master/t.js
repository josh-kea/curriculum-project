
let path = "cola"; // this would be dynamic
let base = "http://kea-alt-del.dk/t5/site/imgs/";
let smallImg = base + "small/" + path + "-sm.jpg";
let mediumImg = base + "medium/" + path + "-md.jpg";
let largeImg = base + "large/" + path + ".jpg";


const imgName = "cola"; // this would be dynamic
const base = "http://kea-alt-del.dk/t5/site/imgs/";
const smallImg = base + "small/" + imgName + "-sm.jpg";
const mediumImg = base + "medium/" + imgName + "-md.jpg";
const largeImg = base + "large/" + imgName + ".jpg";

